# Mercado Vecino

Plataforma de pedidos para tiendas de barrio, contenerizada con Docker Compose.

| Servicio | Tecnología | Red | Puerto publicado |
|----------|------------|-----|------------------|
| web      | React + Nginx (sin root) | frontend | 8080 |
| api      | FastAPI + Uvicorn (usuario `app`) | frontend, backend | ninguno |
| db       | PostgreSQL 17 | backend (interna) | ninguno |
| redis    | Redis 7.4 con contraseña | backend (interna) | ninguno |

## Requisitos

Docker Engine 24+, Docker Compose v2+, Git y `openssl`. En Windows, usar Git Bash.

## Pasos para levantar el proyecto

```bash
git clone <URL-DEL-REPOSITORIO> mercado-vecino && cd mercado-vecino
cp .env.example .env
mkdir secrets && for n in db_password db_admin_password redis_password; do openssl rand -base64 24 > secrets/$n.txt; done
docker compose -f compose.yaml up -d --build
```

Verificar: `docker compose ps` (db, redis y api en estado healthy) y abrir http://localhost:8080
o ejecutar `curl http://localhost:8080/api/tiendas`.

## Apagar

- `docker compose down` conserva los datos.
- `docker compose down -v` borra también los volúmenes (se pierden los datos).

## Seguridad

- Las contraseñas viven en `secrets/` (ignorada por Git) y llegan a los contenedores como archivos en `/run/secrets/`.
- La API usa el rol `mercado_app` (solo SELECT/INSERT/UPDATE/DELETE sobre sus tablas), no el superusuario.
- Solo `web` publica un puerto. La red `backend` es interna.
- `compose.override.yaml` es solo para desarrollo: en producción se usa `-f compose.yaml`.
