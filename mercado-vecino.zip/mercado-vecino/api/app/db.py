import psycopg

from app import config


def obtener_conexion():
    """Abre una conexión a PostgreSQL. Se usa con `with` para cerrarla sola."""
    return psycopg.connect(
        host=config.DB_HOST,
        dbname=config.DB_NAME,
        user=config.DB_USER,
        password=config.DB_PASSWORD,
    )
