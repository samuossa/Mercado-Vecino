-- Esquema y datos semilla de Mercado Vecino
-- La imagen oficial de PostgreSQL ejecuta este archivo solo cuando el volumen de datos está vacío.

CREATE TABLE tiendas (
    id     SERIAL PRIMARY KEY,
    nombre TEXT NOT NULL,
    barrio TEXT NOT NULL
);

CREATE TABLE productos (
    id        SERIAL PRIMARY KEY,
    tienda_id INTEGER NOT NULL REFERENCES tiendas(id),
    nombre    TEXT NOT NULL,
    precio    NUMERIC(10, 2) NOT NULL CHECK (precio >= 0)
);

CREATE TABLE pedidos (
    id         SERIAL PRIMARY KEY,
    tienda_id  INTEGER NOT NULL REFERENCES tiendas(id),
    cliente    TEXT NOT NULL,
    total      NUMERIC(10, 2) NOT NULL CHECK (total >= 0),
    creado_en  TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO tiendas (nombre, barrio) VALUES
    ('Tienda Doña Rosa',    'Chapinero'),
    ('Abarrotes El Vecino', 'Teusaquillo'),
    ('Minimercado La 45',   'Palermo'),
    ('Frutas y Verduras Andes', 'Usaquén');

INSERT INTO productos (tienda_id, nombre, precio) VALUES
    (1, 'Leche entera 1L',  4200),
    (1, 'Pan tajado',       5800),
    (2, 'Arroz 1kg',        4600),
    (2, 'Huevos x12',      11500),
    (3, 'Café molido 500g', 18900),
    (4, 'Plátano maduro',   3000);

INSERT INTO pedidos (tienda_id, cliente, total) VALUES
    (1, 'Carlos Pérez', 10000),
    (3, 'Ana Gómez',    18900);
