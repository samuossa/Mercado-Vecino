-- Rol de la aplicación con privilegios mínimos (distinto del superusuario).
-- Se ejecuta SOLO cuando el volumen está vacío, después de 01_esquema.sql.
-- La clave se lee del secreto de Compose: nunca se escribe en este archivo.
-- tr -d quita el salto de línea (CRLF si el secreto se generó en Windows).
\set app_password `tr -d '\r\n' < /run/secrets/db_password`

CREATE ROLE mercado_app
    LOGIN
    PASSWORD :'app_password'
    NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION;

GRANT CONNECT ON DATABASE :"DBNAME" TO mercado_app;
GRANT USAGE ON SCHEMA public TO mercado_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON tiendas, productos, pedidos TO mercado_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO mercado_app;
