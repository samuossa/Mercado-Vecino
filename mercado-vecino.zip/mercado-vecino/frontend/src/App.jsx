import { useEffect, useState } from "react";

// VITE_API_URL queda incrustada en el JavaScript público: nunca un secreto
const API_URL = import.meta.env.VITE_API_URL || "/api";

export default function App() {
  const [tiendas, setTiendas] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch(`${API_URL}/tiendas`)
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then(setTiendas)
      .catch((e) => setError(e.message));
  }, []);

  return (
    <main style={{ fontFamily: "sans-serif", maxWidth: 640, margin: "2rem auto" }}>
      <h1>Mercado Vecino</h1>
      <h2>Tiendas del barrio</h2>
      {error && <p style={{ color: "crimson" }}>No se pudo cargar el catálogo: {error}</p>}
      <ul>
        {tiendas.map((t) => (
          <li key={t.id}>
            <strong>{t.nombre}</strong> — {t.barrio}
          </li>
        ))}
      </ul>
    </main>
  );
}
